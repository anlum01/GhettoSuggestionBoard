import React, { Component } from 'react';
import { BrowserRouter, Route } from 'react-router-dom';

import './App.css';
import * as routes from './components/Navigation';

import Navigation from './components/Navigation';
import LandingPage from './components/Landing/landing';
import RegisterPage from './components/Signup/signup';

/*
 * This kind of routing (passing in function to component props)
 * (1) creates a new instance of component everytime,
 * (2) unmounts prev comp. ony if there was one,
 * (3) and mount newly created component
 */
const App = () =>
  <BrowserRouter>
    <Navigation/>
  </BrowserRouter>

export default App;

/*
<div>
  <Navigation />
  <hr/>
  <Route
    exact path={routes.ROOTPG}
    component={() => <LandingPage />}
  />
  <Route
    exact path={routes.SIGNUP}
    component={() => <RegisterPage />}
  />
</div>
*/
