import { Component } from 'react';
import { Link } from 'react-router-dom';

// dom

class LoginForm extends Component {

  constructor(props) {
    super(props);
  }

  onSubmit = (event) => {
  }

  render() {
    return (
      <form onSubmit={this.onSubmit}>
      </form>
    );
  }

}

export default LoginPage

export {
  LoginForm
};
