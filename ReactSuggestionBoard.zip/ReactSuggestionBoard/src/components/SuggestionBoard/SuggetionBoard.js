import React from 'react';
import { Card, CardImg, CardText, CardBody,
  CardTitle, CardSubtitle, Button } from 'reactstrap';

class SuggestionCard extends Component{
    constructor(props,context){
        super(props,context);
        this.cards = {};

        this.handleAddCard = this.handleAddCard.bind(this);
        this.handleDeleteCard = this.handleDeleteCard.bind(this);

        this.createBoard = this.createBoard.bind(this);
        this.createCard = this.createCard.bind(this);
    }

    //This handles the buttons for adding cards
    handleAddCard(event){

    }

    handleDeleteCard(evente){

    }

    //Renders board called by render()
    createBoard(){

    }

    //Renders card called by board()
    createCard(){

    }

    render(){
        return(
            <div>
                <Button onClick={this.handleAddCard}>Add Suggestion</Button>
                <Button onClick={this.handleDeleteCard}>Delete Suggestion</Button>
            </div>
        )
    }
}