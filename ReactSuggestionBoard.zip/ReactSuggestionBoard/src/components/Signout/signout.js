import React from 'react';
import { Button } from 'react-boostrap';

import { auth } from '../../../functions/firebase';

const SignoutButton = () => {
  <Button type="button" onClick={auth.signOut()}>
    SignOut
  </Button>
}

export default SignoutButton;
