import React, { Component } from 'react';
import { Link, withRouter } from 'react-router-dom';

import { Button } from 'react-bootstrap';

import * as router from '../Navigation';

const RegisterButton = () =>
  <Button type="button" class="button" bsStyle="primary">Sign Up</Button>


const LoginButton = () =>
  <Button type="button" class="button" bsStyle="primary">Log In</Button>


class LandingPage extends Component {

  constructor(props) {
    super(props);
  }

  render() {
    return (
      <div class="button_wrapper">
        <RegisterButton/>
        <br/><br/>
        <LoginButton/>
      </div>, document.querySelector('.app-component')
    );
  }
}

export default withRouter(LandingPage);
