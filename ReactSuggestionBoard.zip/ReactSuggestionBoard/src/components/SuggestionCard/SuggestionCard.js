import React from 'react';
import { Card, CardImg, CardText, CardBody,
  CardTitle, CardSubtitle, Button } from 'reactstrap';

class SuggestionCard extends Component{
    constructor(props, context){
        this.state = {
            str_card_img_url:'',
            str_card_body:'',
            str_card_text:'',
            int_upvote:0,
            int_downvote:0
        }

    }
    
    handleUp(event){
        let upvote = this.state.int_upvote;
        upvote = upvote + 1;
        this.setState({"int_upvote":upvote});
    }

    handleDown(event){
        let downVote = this.state.int_downvote;
        downvote = downvote - 1;
        this.setState({'int_downvote':downvote});
    }

    //This renders a card
    render() {
        return (
            <div>
                <Card>
                    <CardImg></CardImg>
                        <CardBody></CardBody>
                        <CardText></CardText>
                        <Button onClick={this.handleUp}></Button>
                        <Button onClick={this.handleDown}></Button>
                </Card>
            </div>
        );
      }
}