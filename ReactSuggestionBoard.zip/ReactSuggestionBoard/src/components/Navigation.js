import React from 'react';
import { Link } from 'react-router-dom';

//Routes
export const ROOTPG = '/';
export const SIGNUP = '/signup';
export const SIGNIN = '/signin';
export const HOME = '/home';
export const PROFILE = '/profile';

const Navigation = () =>
  <div>
    <ul>
      <li><Link to={ROOTPG}>Landing</Link></li>
      <li><Link to={SIGNUP}>Register</Link></li>
      <li><Link to={SIGNIN}>Sign In</Link></li>
      <li><Link to={HOME}>Home</Link></li>
      <li><Link to={PROFILE}>Profile</Link></li>
    </ul>
  </div>


export default Navigation;
