import React, { Component } from 'react';
import { Link, withRouter } from 'react-router-dom';
import { Button } from 'react-bootstrap';

import { auth } from '../../functions/firebase';
import * as routes from '../Navigation';

const RegisterPage = ({history}) => (
  <div>
    <RegisterForm history={history}></RegisterForm>
  </div>
)

const SIGNUP_STATE = {
  email: '',
  username: '',
  password: '',
  password_attempt2: '',
  error: null
};

const byPropKey = (propertyName, value) => () => ({
  [propertyName]: value,
});

class RegisterForm extends Component {

  constructor(props, context) {
    super(props);
    this.state = { ...SIGNUP_STATE};
    context.setTitle("Register");
  }

  onSubmit = (event) => {
    const {
      email,
      username,
      password,
    } = this.state;

    const history = this.props;

    auth.createUserWithEmailAndPassword(email, password)
      .then(authUser => {
        this.setState(() => ({...SIGNUP_STATE}));
        history.push(routes.HOME);
      })
      .catch(error => {
        this.setState(byPropKey('error', error));
      })

      event.preventDefault(); // manually prevent normal refresh behavior

  }

  render() {
    const {
      email,
      username,
      password,
      password_attempt2
    } = this.state;

    const invalidEntry =
      (password !== password_attempt2 ||
      email === '' || password === '' ||
      password === '' || password_attempt2 === '');

    return (
      <form onSubmit={this.onSubmit}>
        <input
          name = "username"
          value = {username}
          onChange = {event => this.setState(byPropKey(username, event.target.value))}
          type = "text"
          placeholder = "Full Name"
          />
        <input
          name = "email"
          value = {email}
          onChange = {event => this.setState(byPropKey(email, event.target.value))}
          type = "text"
          placeholder = "Email"
          />
        <input
          name = "password"
          value = {password}
          onChange = {event => this.setState(byPropKey(password, event.target.value))}
          type = "password"
          placeholder = "Enter Password"
          />
        <input
          name = "repeat-password"
          value = {password_attempt2}
          onChange = {event => this.setState(byPropKey(password_attempt2, event.target.value))}
          type = "password"
          placeholder = "Re-enter password"
          />
        <Button bsStyle="primary" type="submit" disabled={invalidEntry}>
          Register
        </Button>
      </form>
    )
  }
}

export {
  RegisterForm
};

export default withRouter(RegisterPage);
