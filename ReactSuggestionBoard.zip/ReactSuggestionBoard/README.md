React Suggestions Board
